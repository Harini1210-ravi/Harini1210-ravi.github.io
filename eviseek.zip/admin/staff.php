<?php

session_start();
include("db.php");
if(!isset($_SESSION["aid"]))
{
    echo '<script>window.location.replace("index.php");</script>';
}
$dept = $_GET["dept"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Eviseek</title>

    <style>
        body{
            background-image: url(../image/admin_home.jpeg);
            background-size: 100vw 100vh;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        .table{
            background-color: rgba(255, 255, 255, 0.8) !important;
        }
        .table a{
            font-weight: bold;
        }
    </style>
</head>
<body>
    <?php
        include("admin_header.php");
    ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 offset-md-1">
                <div class="table-responsive">
                    <table class="table table-hover mt-5">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $sql = "select * from eviseek_staff where eviseek_staff_department = '$dept'";
                                $result = mysqli_query($conn, $sql);
                                if(mysqli_num_rows($result) > 0)
                                {
                                    while($row = mysqli_fetch_assoc($result))
                                    {
                                        ?>
                                        <tr>
                                            <td><?=$row["eviseek_staff_name"]?></td>
                                            <td><?=$row["eviseek_staff_email"]?></td>
                                            <td><a href="edit_staff.php?id=<?=$row["eviseek_staff_id"]?>" class="btn btn-warning text-white">Edit</a></td>
                                            <td><a href="delete_staff.php?id=<?=$row["eviseek_staff_id"]?>" class="btn btn-danger">Delete</a></td>
                                        </tr>
                                        <?php
                                    }
                                } 
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>