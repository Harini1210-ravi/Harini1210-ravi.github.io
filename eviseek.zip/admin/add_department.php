<?php

session_start();
include("db.php");
if(!isset($_SESSION["aid"]))
{
    echo '<script>window.location.replace("index.php");</script>';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Eviseek</title>

    <style>
        body{
            background-image: url(../image/admin_home.jpeg);
            background-size: 100vw 100vh;
            background-repeat: no-repeat;
        }
        .card{
            border-radius: 16px !important;
            font-size: 22px;
            font-weight: 500;
            background-color: rgba(255,255,255, 0.8) !important;
            color: #000000;
        }
        .card h3{
            border-bottom: 1px solid #000000;
            padding-bottom: 10px;

        }
        .card input[type=submit]
        {
            /* width: 100px; */
            font-size: 18px;
            font-weight: bold;
            background-color: rgb(8,42,67);
            color: #ffffff;
        }
        .card input[type=text]
        {
            border-radius: 20px;
        }
    </style>
</head>
<body>
    <?php
        include("admin_header.php");
    ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3 mt-5">
                <div class="card mt-5 p-4">
                    <form action="" method="post">
                    <center><h3>Add Department</h3></center>
                        <div class="form-group">
                            <label for="">Department</label>
                            <input type="text" class="form-control" name="eviseek_department" placeholder="Enter the Department" required>
                        </div>
                        <div class="form-group">
                            <label for="">Description</label>
                            <textarea name="eviseek_description" class="form-control" required></textarea>
                        </div>
                        <center>
                            <input type="submit" name="add" class="btn" value="Add">
                        </center>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php

if(isset($_POST["add"]))
{
    $department = $_POST["eviseek_department"];
    $description = $_POST["eviseek_description"];

    $sql = "insert into eviseek_department(eviseek_dept,eviseek_description) values('$department','$description')";
    if(mysqli_query($conn, $sql))
    {
        echo '<script>alert("Department Added Successfull");window.location.replace("add_department.php");</script>';
    }
    else
    {
        echo '<script>alert("Error To Add Department");window.location.replace("add_department.php");</script>';
    }
}