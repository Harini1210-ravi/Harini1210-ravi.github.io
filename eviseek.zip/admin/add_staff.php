<?php

session_start();
include("db.php");
if(!isset($_SESSION["aid"]))
{
    echo '<script>window.location.replace("index.php");</script>';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Eviseek</title>

    <style>
        body{
            background-image: url(../image/admin_home.jpeg);
            background-size: 100vw 100vh;
            background-repeat: no-repeat;
        }
        .card{
            border-radius: 16px !important;
            font-size: 20px;
            font-weight: 500;
            background-color: rgba(255,255,255, 0.8) !important;
            color: #000000;
        }
        .card h3{
            border-bottom: 1px solid #000000;
            padding-bottom: 10px;

        }
        .card input[type=submit]
        {
            /* width: 100px; */
            font-size: 18px;
            font-weight: bold;
            background-color: rgb(8,42,67);
            color: #ffffff;
        }
        .card input
        {
            border-radius: 20px;
        }
        .card .drop
        {
            border-radius: 20px;
        }
    </style>
</head>
<body>
    <?php
        include("admin_header.php");
    ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card p-4 mt-5">
                    <form action="" method="post">
                    <center><h3>Add Staff</h3></center>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="">Department</label>
                                <select class="form-control drop" required name="eviseek_staff_department">
                                    <option selected value="">--- Choose Department ---</option>
                                    <?php
                                    $sql1 = "select * from eviseek_department";
                                    $result1 = mysqli_query($conn, $sql1);
                                    if(mysqli_num_rows($result1) > 0)
                                    {
                                        while($row1 = mysqli_fetch_assoc($result1))
                                        {
                                            ?>
                                            <option value="<?=$row1["eviseek_dept"]?>"><?=$row1["eviseek_dept"]?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                                <!-- <input type="text" class="form-control" name="eviseek_staff_department" placeholder="Enter Department"> -->
                            </div>
                            <div class="form-group col-md-6">
                                <label for="">Name</label>
                                <input type="text" class="form-control" name="eviseek_staff_name" required placeholder="Enter Staff Name">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="">Email</label>
                                <input type="email" class="form-control" name="eviseek_staff_email" required placeholder="Enter Staff Email">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="">Password</label>
                                <input type="password" class="form-control" name="eviseek_staff_password" required placeholder="Enter Staff Password">
                            </div>
                        </div>
                        <center>
                            <input type="submit" name="add" class="btn" value="Add Staff">
                        </center>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php

if(isset($_POST["add"]))
{
    $department = $_POST["eviseek_staff_department"];
    $name = $_POST["eviseek_staff_name"];
    $email = $_POST["eviseek_staff_email"];
    $password = $_POST["eviseek_staff_password"];

    $sql11 = "select * from eviseek_staff where eviseek_staff_email = '$email'";
    $result11 = mysqli_query($conn, $sql11);
    if(mysqli_num_rows($result11) > 0)
    {
        echo ' <script>alert("Email Already Exists");window.location.replace("add_staff.php");</script>';
    }
    else
    {
        $sql = "insert into eviseek_staff(eviseek_staff_department,eviseek_staff_name,eviseek_staff_email,eviseek_staff_password)
        values('$department','$name','$email','$password')";
       if(mysqli_query($conn, $sql))
       {
           echo '<script>alert("Staff Added Successfull");window.location.replace("add_staff.php");</script>';
       }
       else
       {
           echo '<script>alert("Error To Add Staff");window.location.replace("add_staff.php");</script>';
       }
    }
}
