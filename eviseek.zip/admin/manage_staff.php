<?php

session_start();
include("db.php");
if(!isset($_SESSION["aid"]))
{
    echo '<script>window.location.replace("index.php");</script>';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Eviseek</title>

    <style>
        body{
            background-image: url(../image/admin_home.jpeg);
            background-size: 100vw 100vh;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
    </style>
</head>
<body>
    <?php
        include("admin_header.php");
    ?>
    <div class="container">
        <div class="row my-3">
            <?php
                $sql = "select * from eviseek_department";
                $result = mysqli_query($conn, $sql);
                if(mysqli_num_rows($result) > 0)
                {
                    while($row = mysqli_fetch_assoc($result))
                    {
                        ?>
                        <div class="col-md-4">
                            <a href="staff.php?dept=<?=$row["eviseek_dept"]?>">
                                <div class="card py-4 mt-4">
                                    <center><h3><?=$row["eviseek_dept"]?></h3></center>
                                </div>
                            </a>
                        </div>
                        <?php
                    }
                }
            ?>
        </div>
    </div>
</body>
</html>