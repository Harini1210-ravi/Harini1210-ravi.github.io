<?php

session_start();
include("db.php");
if(!isset($_SESSION["aid"]))
{
    echo '<script>window.location.replace("index.php");</script>';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Eviseek</title>

    <style>
        body{
            background-image: url(../image/admin_home.jpeg);
            background-size: 100vw 100vh;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        .table{
            background-color: rgba(255, 255, 255, 0.8) !important;
        }
    </style>
</head>
<body>
    <?php
        include("admin_header.php");
    ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="table-responsive">
                    <table class="table table-hover mt-5">
                        <thead>
                            <tr>
                                <th>Types of Department</th>
                                <th>Edit</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $sql = "select * from eviseek_department";
                                $result = mysqli_query($conn, $sql);
                                if(mysqli_num_rows($result) > 0)
                                {
                                    while($row = mysqli_fetch_assoc($result))
                                    {
                                        ?>
                                        <tr>
                                            <td><?=$row["eviseek_dept"]?></td>
                                            <td><a href="edit_department.php?id=<?=$row["eviseek_dept_id"]?>" class="btn btn-warning text-white">Edit Department</a></td>
                                            <td><a href="delete_department.php?id=<?=$row["eviseek_dept_id"]?>" class="btn btn-danger">Delete Department</a></td>
                                        </tr>
                                        <?php
                                    }
                                } 
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>