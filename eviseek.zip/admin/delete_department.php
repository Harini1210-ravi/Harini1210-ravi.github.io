<?php

include("db.php");

$id = $_GET["id"];

$sql = "select * from eviseek_department where eviseek_dept_id = $id";
$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) > 0)
{
    $row = mysqli_fetch_assoc($result);
    $dept = $row["eviseek_dept"];
    $sql1 = "delete from eviseek_staff where eviseek_staff_department = '$dept'";
    if(mysqli_query($conn, $sql1))
    {
        $sql2 = "delete from eviseek_department where eviseek_dept_id = $id";
        if(mysqli_query($conn, $sql2))
        {
            echo '<script>alert("Deleted Successfull");window.location.replace("manage_department.php");</script>';
        }
        else
        {
            echo '<script>alert("Error to Delete");window.location.replace("manage_department.php");</script>';
        }
    }
}





//  if(mysqli_query($conn,$sql))
//  {
//     echo '<script>alert("Department Deleted Successfull");window.location.replace("manage_department.php");</script>';
//  }
//  else
//  {
//     echo '<script>alert("Error to Delete");window.location.replace("manage_department.php");</script>';
//  }


