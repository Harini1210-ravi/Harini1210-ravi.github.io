<?php

session_start();
include("db.php");
if(!isset($_SESSION["aid"]))
{
    echo '<script>window.location.replace("index.php");</script>';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Eviseek</title>

    <style>
        body{
            background-image: url(../image/admin_home.jpeg);
            background-size: 100vw 100vh;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        .card{
            border-radius: 20px !important;
        }
        .card h4{
            border-bottom: 2px solid #000000;
            padding-bottom: 16px;
        }
    </style>
</head>
<body>
    <?php
        include("admin_header.php");
    ?>
    <div class="container">
        <div class="row">
            <?php
            $sql = "select * from eviseek_department";
            $result = mysqli_query($conn, $sql);
            if(mysqli_num_rows($result) > 0)
            {
                while($row = mysqli_fetch_assoc($result))
                {
                    $dept = $row["eviseek_dept"];
                    $sql1= "select count(*) as t from eviseek_staff where eviseek_staff_department = '$dept'";
                    $result1 = mysqli_query($conn, $sql1);
                    $row1 = mysqli_fetch_assoc($result1);
                    ?>
                    <div class="col-md-4">
                        <div class="card py-4 mt-4">
                            <center><h4><?=$dept?></h4></center>
                            <center><h2><?=$row1["t"]?> Staffs</h2></center>
                        </div>
                    </div>
                    <?php
                }
            }
            ?>
        </div>
    </div>
</body>
</html>