<?php

include("db.php");

$id = $_GET["id"];

$sql1 = "select * from eviseek_staff where eviseek_staff_id = $id";
$result1 = mysqli_query($conn, $sql1);
$row1 = mysqli_fetch_assoc($result1);
$dept = $row1["eviseek_staff_department"];
 

$sql = "delete from eviseek_staff where eviseek_staff_id = $id";
 if(mysqli_query($conn,$sql))
 {
    header("Location: staff.php?dept=$dept");
 }
 else
 {
    echo '<script>alert("Error to Delete");window.location.replace("manage_staff.php");</script>';
 }


