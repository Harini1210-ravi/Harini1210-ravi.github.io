<?php

session_start();
include("db.php");
if(!isset($_SESSION["aid"]))
{
    echo '<script>window.location.replace("index.php");</script>';
}
$id = $_GET["id"];

$sql2 = "select * from eviseek_staff where eviseek_staff_id = '$id'";
$result2 = mysqli_query($conn, $sql2);
$row2 = mysqli_fetch_assoc($result2);
$dept=$row2["eviseek_staff_department"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Eviseek</title>

    <style>
        body{
            background-image: url(../image/admin_home.jpeg);
            background-size: 100vw 100vh;
            background-repeat: no-repeat;
        }
        .card{
            border-radius: 16px !important;
            font-size: 20px;
            font-weight: 500;
            background-color: rgba(255,255,255, 0.8) !important;
            color: #000000;
        }
        .card h3{
            border-bottom: 1px solid #000000;
            padding-bottom: 10px;

        }
        .card input[type=submit]
        {
            /* width: 100px; */
            font-size: 18px;
            font-weight: bold;
            background-color: rgb(8,42,67);
            color: #ffffff;
        }
        .card a{
            font-size: 18px;
            font-weight: bold;
            color: #ffffff;
            border-radius: 20px;
        }
        .card input
        {
            border-radius: 20px;
        }
        .card .drop
        {
            border-radius: 20px;
        }
    </style>
</head>
<body>
    <?php
        include("admin_header.php");
    ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card p-4 mt-5">
                    <form action="" method="post">
                    <center><h3>Update Staff Details</h3></center>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="">Department</label>
                                <select class="form-control drop" name="eviseek_staff_department">
                                    <option><?=$row2["eviseek_staff_department"]?></option>
                                    <?php
                                    $sql1 = "select * from eviseek_department";
                                    $result1 = mysqli_query($conn, $sql1);
                                    if(mysqli_num_rows($result1) > 0)
                                    {
                                        while($row1 = mysqli_fetch_assoc($result1))
                                        {
                                            ?>
                                            <option value="<?=$row1["eviseek_dept"]?>"><?=$row1["eviseek_dept"]?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                                <!-- <input type="text" class="form-control" name="eviseek_staff_department" placeholder="Enter Department"> -->
                            </div>
                            <div class="form-group col-md-6">
                                <label for="">Name</label>
                                <input type="text" class="form-control" value="<?=$row2["eviseek_staff_name"]?>" name="eviseek_staff_name" required placeholder="Enter Staff Name">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="">Email</label>
                                <input type="email" class="form-control" value="<?=$row2["eviseek_staff_email"]?>" name="eviseek_staff_email" required placeholder="Enter Staff Email">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="">Password</label>
                                <input type="password" class="form-control" value="<?=$row2["eviseek_staff_password"]?>" name="eviseek_staff_password" required placeholder="Enter Staff Password">
                            </div>
                        </div>
                        <center>
                            <input type="submit" name="update" class="btn" value="Update">
                            <a href="staff.php?dept=<?=$dept?>" class="btn btn-secondary">Back</a>
                        </center>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php

if(isset($_POST["update"]))
{
    $department = $_POST["eviseek_staff_department"];
    $name = $_POST["eviseek_staff_name"];
    $email = $_POST["eviseek_staff_email"];
    $password = $_POST["eviseek_staff_password"];

    $sql = "update eviseek_staff set eviseek_staff_department='$department',eviseek_staff_name='$name',eviseek_staff_email='$email',eviseek_staff_password='$password' where eviseek_staff_id = $id";
    if(mysqli_query($conn, $sql))
    {
        echo '<script>alert("Updated Successfull");window.location.replace(window.location.href);</script>';
    }
    else
    {
        echo '<script>alert("Error To Update");window.location.replace("manage_staff.php");</script>';
    }
}