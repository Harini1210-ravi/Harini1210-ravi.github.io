-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 06, 2024 at 03:27 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eviseek`
--

-- --------------------------------------------------------

--
-- Table structure for table `eviseek_admin`
--

CREATE TABLE `eviseek_admin` (
  `eviseek_aid` int(11) NOT NULL,
  `eviseek_aemail` varchar(50) NOT NULL,
  `eviseek_apassword` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `eviseek_admin`
--

INSERT INTO `eviseek_admin` (`eviseek_aid`, `eviseek_aemail`, `eviseek_apassword`) VALUES
(1, 'admin@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `eviseek_complaint`
--

CREATE TABLE `eviseek_complaint` (
  `eviseek_complaint_id` int(11) NOT NULL,
  `eviseek_complaint_name` varchar(100) NOT NULL,
  `eviseek_complaint_email` varchar(50) NOT NULL,
  `eviseek_complaint_department` varchar(100) NOT NULL,
  `eviseek_complaint_image` varchar(100) NOT NULL,
  `eviseek_complaint_message` text NOT NULL,
  `eviseek_complaint_uid` varchar(100) NOT NULL,
  `eviseek_complaint_status` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `eviseek_complaint`
--

INSERT INTO `eviseek_complaint` (`eviseek_complaint_id`, `eviseek_complaint_name`, `eviseek_complaint_email`, `eviseek_complaint_department`, `eviseek_complaint_image`, `eviseek_complaint_message`, `eviseek_complaint_uid`, `eviseek_complaint_status`, `date`) VALUES
(1, 'ganesh kumar', 'ganesh@gmail.com', 'Police Department', 'HELMET (1).jpg', 'sdfgn', '1', 'Complaint Seen', ''),
(2, 'ganesh kumar', 'ganesh@gmail.com', 'Electricity Department', 's9.PNG', 'sdfdghnm', '1', 'Resolved', ''),
(3, 'ganesh kumar', 'ganesh@gmail.com', 'Police Department', 't.jpg', 'nvxfhbhfhfgfgf', '1', 'Processing', ''),
(4, 'ganesh kumar', 'ganesh@gmail.com', 'Electricity Department', 'oil.jpg', 'saefghm', '1', 'Resolved', '2024-06-26'),
(5, 'ganesh kumar', 'ganesh@gmail.com', 'Police Department', 'oil.jpg', 'Every item in our extensive product range is carefully selected and rigorously tested to ensure it meets our exacting standards. From state-of-the-art surgical instruments to essential healthcare supplies, we are dedicated to delivering excellence.\n\nI am incredibly proud of the passionate team we have built at [Your Company Name].', '1', 'Resolved', '2024-06-26');

-- --------------------------------------------------------

--
-- Table structure for table `eviseek_department`
--

CREATE TABLE `eviseek_department` (
  `eviseek_dept_id` int(11) NOT NULL,
  `eviseek_dept` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `eviseek_department`
--

INSERT INTO `eviseek_department` (`eviseek_dept_id`, `eviseek_dept`) VALUES
(1, 'Electricity Department'),
(2, 'Police Department');

-- --------------------------------------------------------

--
-- Table structure for table `eviseek_staff`
--

CREATE TABLE `eviseek_staff` (
  `eviseek_staff_id` int(11) NOT NULL,
  `eviseek_staff_department` varchar(100) NOT NULL,
  `eviseek_staff_name` varchar(100) NOT NULL,
  `eviseek_staff_email` varchar(100) NOT NULL,
  `eviseek_staff_password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `eviseek_staff`
--

INSERT INTO `eviseek_staff` (`eviseek_staff_id`, `eviseek_staff_department`, `eviseek_staff_name`, `eviseek_staff_email`, `eviseek_staff_password`) VALUES
(9, 'Police Department', 'adghfn', 'hari@gmail.com', 'aa'),
(10, 'Electricity Department', 'regu', 'regu@gmail.com', 's'),
(13, 'Electricity Department', 'a', 'hari@gmail.com', 'a'),
(14, 'Police Department', 'bala', 'bala@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `eviseek_user`
--

CREATE TABLE `eviseek_user` (
  `eviseek_user_id` int(11) NOT NULL,
  `eviseek_user_name` varchar(100) NOT NULL,
  `eviseek_user_phone` varchar(50) NOT NULL,
  `eviseek_user_email` varchar(100) NOT NULL,
  `eviseek_user_password` varchar(100) NOT NULL,
  `eviseek_user_image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `eviseek_user`
--

INSERT INTO `eviseek_user` (`eviseek_user_id`, `eviseek_user_name`, `eviseek_user_phone`, `eviseek_user_email`, `eviseek_user_password`, `eviseek_user_image`) VALUES
(1, 'ganesh kumar', '9876543211', 'ganesh@gmail.com', '1234', 'user.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `eviseek_admin`
--
ALTER TABLE `eviseek_admin`
  ADD PRIMARY KEY (`eviseek_aid`);

--
-- Indexes for table `eviseek_complaint`
--
ALTER TABLE `eviseek_complaint`
  ADD PRIMARY KEY (`eviseek_complaint_id`);

--
-- Indexes for table `eviseek_department`
--
ALTER TABLE `eviseek_department`
  ADD PRIMARY KEY (`eviseek_dept_id`);

--
-- Indexes for table `eviseek_staff`
--
ALTER TABLE `eviseek_staff`
  ADD PRIMARY KEY (`eviseek_staff_id`);

--
-- Indexes for table `eviseek_user`
--
ALTER TABLE `eviseek_user`
  ADD PRIMARY KEY (`eviseek_user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `eviseek_admin`
--
ALTER TABLE `eviseek_admin`
  MODIFY `eviseek_aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `eviseek_complaint`
--
ALTER TABLE `eviseek_complaint`
  MODIFY `eviseek_complaint_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `eviseek_department`
--
ALTER TABLE `eviseek_department`
  MODIFY `eviseek_dept_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `eviseek_staff`
--
ALTER TABLE `eviseek_staff`
  MODIFY `eviseek_staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `eviseek_user`
--
ALTER TABLE `eviseek_user`
  MODIFY `eviseek_user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
