<?php
session_start();
include("db.php");
if (!isset($_SESSION["uid"])) {
    echo '<script>window.location.replace("index.php");</script>';
}
$uid = $_SESSION["uid"];
$sql = "SELECT * FROM eviseek_user WHERE eviseek_user_id = '$uid'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eviseek</title>
    <style>
        body {
            background-image: url(../image/user.jpg);
            background-size: 100vw 100vh;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        .card {
            border-radius: 20px !important;
            font-size: 20px;
            font-weight: bold;
            background-color: rgba(0, 0, 0, 0.8) !important;
            color: #ffffff;
        }
        .card h3 {
            border-bottom: 1px solid #ffffff;
            padding-bottom: 10px;
        }
        input {
            border-radius: 16px !important;
            border: none;
        }
        .card p {
            font-size: 16px;
            margin-top: 10px;
        }
        .card .drop {
            border-radius: 20px;
        }
        input[type=submit]
        {
            /* width: 100px; */
            font-size: 18px;
            font-weight: bold;
            color: #ffffff;
        }
    </style>
</head>
<body>
    <?php include("user_header.php"); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card p-4 my-5">
                    <form action="" method="post" enctype="multipart/form-data">
                        <center><h3>Complaint Box</h3></center>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="">Name</label>
                                <input type="hidden" class="form-control" name="eviseek_complaint_status" value="Pending">
                                <input type="hidden" class="form-control" name="eviseek_complaint_uid" value="<?=$uid?>">
                                <input type="text" class="form-control" name="eviseek_complaint_name" placeholder="Enter Your Name" value="<?=$row['eviseek_user_name']?>" readonly>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="">Email</label>
                                <input type="email" class="form-control" name="eviseek_complaint_email" placeholder="Enter Your Email" value="<?=$row['eviseek_user_email']?>" readonly>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="">Department</label>
                                <select class="form-control drop" required name="eviseek_complaint_department">
                                    <option selected value="">--- Choose Department ---</option>
                                    <?php
                                    $sql1 = "SELECT * FROM eviseek_department";
                                    $result1 = mysqli_query($conn, $sql1);
                                    if (mysqli_num_rows($result1) > 0) {
                                        while ($row1 = mysqli_fetch_assoc($result1)) {
                                            ?>
                                            <option value="<?=$row1["eviseek_dept"]?>"><?=$row1["eviseek_dept"]?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="">Image (.jpg)</label>
                                <input type="file" class="form-control" name="img" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label>Choose District</label>
                                <select name="district" class="form-control" required onchange="choosestate(this.value)">
                                    <option selected value="">Select your district</option>
                                    <?php
                                    $sql2="select * from eviseek_district";
                                    $result2=mysqli_query($conn,$sql2);
                                    if(mysqli_num_rows($result2)>0)
                                    {
                                        while($row2=mysqli_fetch_assoc($result2))
                                        {
                                        ?>
                                            <option value="<?=$row2['id']?>"><?=$row2["name"]?></option>
                                        <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Choose City</label>
                                <select name="city" class="form-control" id="city" onchange="choose_city(this.value)" required>
                                    <option selected value="">Select your city</option>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Choose Area</label>
                                <select name="area" id="area" class="form-control" required>
                                    <option selected value="">Select your area</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="">Audio or Video (.mp3 or .mp4)</label>
                                <input type="file" class="form-control" name="eviseek_file" required>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="">Message</label>
                                <textarea name="eviseek_complaint_message" class="form-control" required></textarea>
                            </div>
                        </div>
                        <center><input type="submit" name="submit" class="btn btn-danger" value="Submit"></center>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
function choosestate(a)
{
const xmlhttp = new XMLHttpRequest();
  xmlhttp.onload = function() {
      document.getElementById("city").innerHTML = this.responseText;
    }
  xmlhttp.open("GET", "getcity.php?id=" + a);
  xmlhttp.send();
} 
function choose_city(b)
{
const xmlhttp = new XMLHttpRequest();
  xmlhttp.onload = function() {
      document.getElementById("area").innerHTML = this.responseText;
    }
  xmlhttp.open("GET", "getarea.php?id=" + b);
  xmlhttp.send();
}
</script>
</body>
</html>
<?php

if (isset($_POST["submit"])) {
    $targetDir = "uploads/";
    $targetFileImg = $targetDir . basename($_FILES["img"]["name"]);
    $targetFileAV = $targetDir . basename($_FILES["eviseek_file"]["name"]);
    $imageFileType = strtolower(pathinfo($targetFileImg, PATHINFO_EXTENSION));
    $audioVideoFileType = strtolower(pathinfo($targetFileAV, PATHINFO_EXTENSION));
    $allowedImageTypes = array("jpg", "jpeg");
    $allowedAVTypes = array("mp3", "mp4");

    // Check if the file type is an allowed image type
    if (in_array($imageFileType, $allowedImageTypes) && in_array($audioVideoFileType, $allowedAVTypes)) {
        // Attempt to move the uploaded files to the specified directory
        if (move_uploaded_file($_FILES["img"]["tmp_name"], $targetFileImg) && move_uploaded_file($_FILES["eviseek_file"]["tmp_name"], $targetFileAV)) {
            $imageName = $_FILES["img"]["name"];
            $fileName = $_FILES["eviseek_file"]["name"];
            $id = $_POST["eviseek_complaint_uid"];
            $name = $_POST["eviseek_complaint_name"];
            $department = $_POST["eviseek_complaint_department"];
            $email = $_POST["eviseek_complaint_email"];
            $message = $_POST["eviseek_complaint_message"];
            $status = $_POST["eviseek_complaint_status"];
            $district = $_POST["district"];
            $city = $_POST["city"];
            $area = $_POST["area"];
            $date = date("Y-m-d");
            $sql2 = "INSERT INTO eviseek_complaint (
                        eviseek_complaint_name,
                        eviseek_complaint_email,
                        eviseek_complaint_department,
                        eviseek_complaint_image,
                        eviseek_complaint_message,
                        eviseek_complaint_uid,
                        eviseek_complaint_status,
                        date,
                        eviseek_complaint_file,
                        district,
                        city,
                        areas
                    ) VALUES (
                        '$name',
                        '$email',
                        '$department',
                        '$imageName',
                        '$message',
                        '$id',
                        '$status',
                        '$date',
                        '$fileName',
                        '$district',
                        '$city',
                        '$area'
                    )";
            
            if (mysqli_query($conn, $sql2)) {
                echo '<script>alert("Complaint Added Successfully");window.location.replace("add_complaint.php");</script>';
            } else {
                echo '<script>alert("Try Again Later");window.location.replace("add_complaint.php");</script>';
            }
        } else {
            echo '<script>alert("Sorry, there was an error uploading your file.");window.location.replace("add_complaint.php");</script>';
        }
    } else {
        echo '<script>alert("Sorry, only JPG, JPEG, PNG, GIF, MP3, MP4, WAV, and AVI files are allowed.");window.location.replace("add_complaint.php");</script>';
    }
}
?>
