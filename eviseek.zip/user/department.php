<?php

session_start();
include("db.php");
if(!isset($_SESSION["uid"]))
{
    echo '<script>window.location.replace("index.php");</script>';
}
$uid = $_SESSION["uid"];
$sql = "select * from eviseek_user where eviseek_user_id = '$uid'";
$result= mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Eviseek</title>

    <style>
        body{
            background-image: url(../image/user.jpg);
            background-size: 100vw 100vh;
            background-repeat: no-repeat;
            background-attachment: fixed;
            
        }
        .card h3{
            color: #000000;
        }
    </style>
</head>
<body>
    <?php
        include("user_header.php");
    ?>
    <div class="container">
        <div class="row">
            <?php
                $sql = "select * from eviseek_department";
                $result = mysqli_query($conn, $sql);
                if(mysqli_num_rows($result) > 0)
                {
                    while($row = mysqli_fetch_assoc($result))
                    {
                        ?>
                        <div class="col-md-4">
                            <a href="description.php?dept=<?=$row["eviseek_dept"]?>">
                                <div class="card py-4 mt-4">
                                    <center><h3><?=$row["eviseek_dept"]?></h3></center>
                                </div>
                            </a>
                        </div>
                        <?php
                    }
                }
            ?>
        </div>
    </div>
</body>
</html>