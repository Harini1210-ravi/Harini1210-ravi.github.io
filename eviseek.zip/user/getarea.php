<?php
$id=$_GET["id"];
include('db.php');
$sql="select * from eviseek_area where citie_id=$id";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
?>
<select name="area" id="area" class="custom-select" required>
<option selected value="">Select your area</option>
<?php
while($row=mysqli_fetch_assoc($result))
{
?>
<option value="<?=$row['id']?>"><?=$row["name"]?></option>
<?php
}
}
else
{
    ?>
  <select name="area" class="custom-select" id="area" required>
     <option selected value="">Select your area</option>
  </select>
    <?php
}
?>
</select>
