<?php

session_start();
include("db.php");
if (!isset($_SESSION["uid"])) {
    echo '<script>window.location.replace("index.php");</script>';
}
$uid = $_SESSION["uid"];
$ID = $_GET["id"];
$sql = "SELECT * FROM eviseek_complaint WHERE eviseek_complaint_id = '$ID'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eviseek</title>
    <style>
        body {
            background-image: url(../image/user.jpg);
            background-size: 100vw 100vh;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        .card {
            border-radius: 20px !important;
            font-size: 20px;
            font-weight: bold;
            background-color: rgba(0, 0, 0, 0.8) !important;
            color: #ffffff;
        }
        .card h3 {
            border-bottom: 1px solid #ffffff;
            padding-bottom: 10px;
        }
        input {
            border-radius: 16px !important;
            border: none;
        }
        .card p {
            font-size: 16px;
            margin-top: 10px;
        }
        .card .drop {
            border-radius: 20px;
        }
    </style>
</head>
<body>
    <?php include("user_header.php"); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card p-4 my-5">
                    <form action="" method="post" enctype="multipart/form-data">
                        <center><h3>Complaint Details</h3></center>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="">Department</label>
                                <input type="text" class="form-control" value="<?=$row['eviseek_complaint_department']?>" readonly>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="">Date</label>
                                <input type="email" class="form-control" value="<?=$row['date']?>" readonly>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="">Message</label>
                                <textarea class="form-control" readonly><?=$row['eviseek_complaint_message']?></textarea>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-12">
                            <label for="">Image</label>
                                <img src="uploads/<?=$row["eviseek_complaint_image"]?>" class="form-control" height="150px" alt="">
                            </div>
                            <div class="form-group col-md-12">
                            <label for="">Video or Audio</label>
                            <video width="100%" height="200" controls>
                                <source src="../user/uploads/<?=$row["eviseek_complaint_file"]?>" class="form-control" type="video/mp4">
                                <source src="../user/uploads/<?=$row["eviseek_complaint_file"]?>" class="form-control" type="audio/mp3">
                                Your browser does not support.
                            </video>
                        </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
