<?php

session_start();
include("db.php");
if(!isset($_SESSION["uid"]))
{
    echo '<script>window.location.replace("index.php");</script>';
}
$dept = $_GET["dept"];
$uid = $_SESSION["uid"];
$sql = "select * from eviseek_department where eviseek_dept = '$dept'";
$result= mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Eviseek</title>

    <style>
        body{
            background-image: url(../image/user.jpg);
            background-size: 100vw 100vh;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        .card h3{
            border-bottom: 2px solid #000000;
            padding-bottom: 17px;
        }
        .card pre{
            white-space: pre-wrap;      
            padding: 10px;
        }
    </style>
</head>
<body>
    <?php
        include("user_header.php");
    ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 my-4">
                <div class="card p-4" style="background-color: rgba(255, 255, 255, 0.7);">
                    <center>
                        <h3><?=$row["eviseek_dept"]?></h3>
                    </center>
                    <pre class="text-justify mt-2"><?=$row["eviseek_description"]?></pre>
                </div>
            </div>
        </div>
    </div>
</body>
</html>