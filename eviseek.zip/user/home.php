<?php

session_start();
include("db.php");
if(!isset($_SESSION["uid"]))
{
    echo '<script>window.location.replace("index.php");</script>';
}
$uid = $_SESSION["uid"];
$sql = "select * from eviseek_user where eviseek_user_id = '$uid'";
$result= mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Eviseek</title>

    <style>
        body{
            background-image: url(../image/user.jpg);
            background-size: 100vw 100vh;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        .card{
            border-radius: 20px !important;
            font-size: 20px;
            font-weight: bold;
            background-color: rgba(0, 0, 0, 0.8) !important;
            color: #ffffff;
        }
        .card h3{
            border-bottom: 1px solid #ffffff;
            padding-bottom: 10px;

        }
        input{
            border-radius: 16px !important;
            border: none;
        }
        .card p{
            font-size: 16px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <?php
        include("user_header.php");
    ?>
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card p-4 mt-5">
                    <form action="" method="post">
                        <center><h3>Update Profile</h3></center>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="">Name</label>
                                <input type="text" class="form-control" name="eviseek_user_name" placeholder="Enter Your Name" value="<?=$row['eviseek_user_name']?>" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="">Mobile No.</label>
                                <input type="number" class="form-control" name="eviseek_user_phone" placeholder="Enter Mobile No." value="<?=$row['eviseek_user_phone']?>" required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="">Email</label>
                                <input type="email" class="form-control" name="eviseek_user_email" placeholder="Enter Your Email" value="<?=$row['eviseek_user_email']?>" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="">Password</label>
                                <input type="password" class="form-control" name="eviseek_user_password" placeholder="Enter Your Password" value="<?=$row['eviseek_user_password']?>" required>
                            </div>
                        </div>
                        <center><input type="submit" name="update" class="btn btn-danger" value="Upadte"></center>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php

if(isset($_POST["update"]))
{
    $name = $_POST["eviseek_user_name"];
    $phone = $_POST["eviseek_user_phone"];
    $email = $_POST["eviseek_user_email"];
    $password = $_POST["eviseek_user_password"];

    $sql1 = "update eviseek_user set eviseek_user_name = '$name',eviseek_user_phone = '$phone',eviseek_user_email = '$email',eviseek_user_password = '$password' 
    where eviseek_user_id = $uid";
    if(mysqli_query($conn, $sql1))
    {
        echo '<script>alert("Updated Successfully");window.location.replace("home.php");</script>';
    }
    else
    {
        echo '<script>alert("Error to Update");window.location.replace("home.php");</script>';
    } 
}