<?php
$id=$_GET["id"];
include('db.php');
$sql="select * from eviseek_cities where district_id=$id";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0)
{
?>
<select name="city" class="form-control" required onchange="choose_city(this.value)">
<option selected value="">Select your city</option>
<?php
while($row=mysqli_fetch_assoc($result))
{
?>
<option value="<?=$row['id']?>"><?=$row["name"]?></option>
<?php
}
}
else
{
    ?>
  <select name="city" class="form-control" id="city" required onchange="choose_city(this.value)">
     <option selected value="">Select your city</option>
  </select>
    <?php
}
?>
</select>
