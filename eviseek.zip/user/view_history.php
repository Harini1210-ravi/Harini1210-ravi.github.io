<?php

session_start();
include("db.php");
if(!isset($_SESSION["uid"]))
{
    echo '<script>window.location.replace("index.php");</script>';
}
$uid = $_SESSION["uid"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Eviseek</title>

    <style>
        body{
            background-image: url(../image/user.jpg);
            background-size: 100vw 100vh;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        .table{
            background-color: rgba(0,0,0, 0.8) !important;
            color: #ffffff;
        }
        .table a{
            font-weight: bold;
        }
    </style>
</head>
<body>
    <?php
        include("user_header.php");
    ?>
    <div class="container">
        <div class="row">
            <div class="col-md-10 offset-md-1">
                <div class="table-responsive">
                    <table class="table table-hover mt-5">
                        <thead>
                            <tr>
                                <th>Department</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $sql = "select * from eviseek_complaint where eviseek_complaint_uid = '$uid'";
                                $result = mysqli_query($conn, $sql);
                                if(mysqli_num_rows($result) > 0)
                                {
                                    while($row = mysqli_fetch_assoc($result))
                                    {
                                        ?>
                                        <tr>
                                            <td><?=$row["eviseek_complaint_department"]?></td>
                                            <td><?=$row["eviseek_complaint_status"]?></td>
                                            <td><a href="view_more.php?id=<?=$row["eviseek_complaint_id"]?>" class="btn btn-danger">View</a></td>
                                        </tr>
                                        <?php
                                    }
                                } 
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>