<?php

session_start();
include("db.php");
if(!isset($_SESSION["sid"]))
{
    echo '<script>window.location.replace("index.php");</script>';
}
$sid = $_SESSION["sid"];
$sql = "select * from eviseek_staff where eviseek_staff_id = '$sid'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$dept = $row["eviseek_staff_department"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Eviseek</title>

    <style>
        body{
            background-image: url(../image/staff-log-bg.jpg);
            background-size: 100vw 100vh;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        .card{
            border-radius: 20px !important;
        }
        .card h4{
            border-bottom: 2px solid #000000;
            padding-bottom: 16px;
        }
        .table{
            background-color: rgba(255, 255, 255, 0.8) !important;
            color: #000000;
        }
    </style>
</head>
<body>
    <?php
        include("staff_header.php");
    ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <center><h2 class="bg-dark p-3 mt-3" style="border-radius: 20px;color:#ffffff">Complaints</h2></center>
                <div class="table-responsive">
                    <table class="table table-hover mt-3">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>email</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $sql1 = "select * from eviseek_complaint where eviseek_complaint_department = '$dept'";
                                $result1 = mysqli_query($conn, $sql1);
                                if(mysqli_num_rows($result1) > 0)
                                {
                                    while($row1 = mysqli_fetch_assoc($result1))
                                    {
                                        $status = $row1["eviseek_complaint_status"];
                                        if($status == "Resolved" )
                                        {
                                        
                                        }
                                        else
                                        {
                                            ?>
                                            <tr>
                                            <td><?=$row1["eviseek_complaint_name"]?></td>
                                            <td><?=$row1["eviseek_complaint_email"]?></td>
                                            <td><?=$row1["eviseek_complaint_status"]?></td>
                                            <td><a href="view.php?id=<?=$row1["eviseek_complaint_id"]?>" class="btn btn-danger">View</a></td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>