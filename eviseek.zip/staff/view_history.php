<?php

session_start();
include("db.php");
if(!isset($_SESSION["sid"]))
{
    echo '<script>window.location.replace("index.php");</script>';
}
$sid = $_SESSION["sid"];
$sql1 = "select * from eviseek_staff where eviseek_staff_id = '$sid'";
$result1 = mysqli_query($conn, $sql1);
$row1 = mysqli_fetch_assoc($result1);
$dept = $row1["eviseek_staff_department"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Eviseek</title>

    <style>
        body{
            background-image: url(../image/staff-log-bg.jpg);
            background-size: 100vw 100vh;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        .table{
            background-color: rgba(255, 255, 255, 0.9) !important;
            font-weight: 500;
        }
        .table a{
            font-weight: bold;
        }
        .table thead{
            font-size: 20px;
        }
    </style>
</head>
<body>
    <?php
        include("staff_header.php");
    ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
            <center><h2 class="bg-dark p-3 mt-3" style="border-radius: 20px;color:#ffffff">Complaint History</h2></center>
                <div class="table-responsive">
                    <table class="table table-hover mt-3">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <!-- <th>Email</th> -->
                                <th>Message</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $sql = "select * from eviseek_complaint where eviseek_complaint_department = '$dept'";
                                $result = mysqli_query($conn, $sql);
                                if(mysqli_num_rows($result) > 0)
                                {
                                    while($row = mysqli_fetch_assoc($result))
                                    {
                                        ?>
                                        <tr>
                                            <td><?=$row["eviseek_complaint_name"]?></td>
                                            <!-- <td><?=$row["eviseek_complaint_email"]?></td> -->
                                            <td class="text-justify"><?=$row["eviseek_complaint_message"]?></td>
                                            <td><?=$row["eviseek_complaint_status"]?></td>
                                        </tr>
                                        <?php
                                    }
                                } 
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>