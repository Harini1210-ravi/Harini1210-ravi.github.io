<?php

session_start();
include("db.php");
if (!isset($_SESSION["sid"])) {
    echo '<script>window.location.replace("index.php");</script>';
}
$ID = $_GET["id"];
$sql = "SELECT * FROM eviseek_complaint WHERE eviseek_complaint_id = '$ID'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$district = $row["district"];
$city = $row["city"];
$area = $row["areas"];

$sql1 = "select * from eviseek_district where id = '$district'";
$result1 = mysqli_query($conn, $sql1);
$row1 = mysqli_fetch_assoc($result1);

$sql2 = "select * from eviseek_cities where id = '$city'";
$result2 = mysqli_query($conn, $sql2);
$row2 = mysqli_fetch_assoc($result2);

$sql3 = "select * from eviseek_area where id = '$area'";
$result3 = mysqli_query($conn, $sql3);
$row3 = mysqli_fetch_assoc($result3);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eviseek</title>
    <style>
        body {
            background-image: url(../image/staff-log-bg.jpg);
            background-size: 100vw 100vh;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        .card {
            border-radius: 20px !important;
            font-size: 20px;
            font-weight: bold;
            background-color: rgba(255, 255, 255, 0.8) !important;
        }
        .card h3 {
            border-bottom: 1px solid #000000;
            padding-bottom: 10px;
        }
        input {
            border-radius: 16px !important;
            border: none;
        }
        .card p {
            font-size: 16px;
            margin-top: 10px;
        }
        .card .drop {
            border-radius: 20px;
        }
    </style>
</head>
<body>
    <?php include("staff_header.php"); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card p-4 my-5">
                    <form action="" method="post" enctype="multipart/form-data">
                        <center><h3>Complaint Details</h3></center>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="">Name</label>
                                <input type="text" class="form-control" value="<?=$row['eviseek_complaint_name']?>" readonly>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="">Date</label>
                                <input type="email" class="form-control" value="<?=$row['date']?>" readonly>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="">Message</label>
                                <textarea class="form-control" readonly><?=$row['eviseek_complaint_message']?></textarea>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-4">
                                <label for="">District</label>
                                <input type="text" class="form-control" value="<?=$row1['name']?>" readonly>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="">City</label>
                                <input type="text" class="form-control" value="<?=$row2['name']?>" readonly>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="">Area</label>
                                <input type="text" class="form-control" value="<?=$row3['name']?>" readonly>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="">Image</label>
                                <img src="../user/uploads/<?=$row["eviseek_complaint_image"]?>" class="form-control" height="250px" alt="">
                            </div>
                            <div class="form-group col-md-12">
                            <label for="">Video or Audio</label>
                                <video width="100%" height="200" controls>
                                    <source src="../user/uploads/<?=$row["eviseek_complaint_file"]?>" class="form-control" type="video/mp4">
                                    <source src="../user/uploads/<?=$row["eviseek_complaint_file"]?>" class="form-control" type="audio/mp3">
                                    Your browser does not support.
                                </video>
                            </div>
                            <!-- <div class="form-group col-md-12">
                                <label for="">Video or Audio</label>
                                <audio controls>
                                <source src="../user/uploads/<?=$row["eviseek_complaint_file"]?>" class="form-control" type="audio/mp3">
                                <source src="horse.mp3" type="audio/mpeg">
                                Your browser does not support the audio element.
                                </audio>
                            </div> -->
                        </div>
                        <div class="form-row mt-2">
                            <div class="dropdown form_group col-md-12">
                            <button class="btn btn-secondary dropdown-toggle form-control" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Update Status
                            </button>
                            <div class="dropdown-menu p-3" aria-labelledby="dropdownMenu2">
                                <div class="form-group">
                                    <input type="submit" name="process1" value="Complaint Seen" class="form-control">
                                </div>
                                <div class="form-group">
                                    <input type="submit" name="process2" value="Processing" class="form-control">
                                </div>
                                <div class="form-group">
                                    <input type="submit" name="process3" value="Cancelled" class="form-control">
                                </div>
                                <div class="form-group">
                                    <input type="submit" name="process4" value="Resolved" class="form-control">
                                </div>
                            </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php

if(isset($_POST["process1"]))
{
    $sql = "update eviseek_complaint set eviseek_complaint_status = 'Complaint Seen' where eviseek_complaint_id = '$ID'";
    if(mysqli_query($conn, $sql))
    {
        echo '<script>alert("Status Updated");window.location.replace("home.php");</script>';
    }
}
if(isset($_POST["process2"]))
{
    $sql = "update eviseek_complaint set eviseek_complaint_status = 'Processing' where eviseek_complaint_id = '$ID'";
    if(mysqli_query($conn, $sql))
    {
        echo '<script>alert("Status Updated");window.location.replace("home.php");</script>';
    }
}
if(isset($_POST["process3"]))
{
    $sql = "update eviseek_complaint set eviseek_complaint_status = 'Cancelled' where eviseek_complaint_id = '$ID'";
    if(mysqli_query($conn, $sql))
    {
        echo '<script>alert("Status Updated");window.location.replace("home.php");</script>';
    }
}
if(isset($_POST["process4"]))
{
    $sql = "update eviseek_complaint set eviseek_complaint_status = 'Resolved' where eviseek_complaint_id = '$ID'";
    if(mysqli_query($conn, $sql))
    {
        echo '<script>alert("Status Updated");window.location.replace("home.php");</script>';
    }
}
