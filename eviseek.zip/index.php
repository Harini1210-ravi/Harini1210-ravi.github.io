<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Eviseek</title>

    <style>
          body {
            background-image: url(../image/admin_home.jpeg);
            background-size: 100vw 100vh;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        .card {
            border-radius: 20px !important;
            font-size: 20px;
            font-weight: bold;
            background-color: #000000 !important;
            color: #ffffff;
        }
        .card h3 {
            border-bottom: 1px solid #ffffff !important;
            padding-bottom: 10px;
        }
        input {
            border-radius: 16px !important;
            border: none;
        }
        .card p {
            font-size: 16px;
            margin-top: 10px;
        }
        .card .drop {
            border-radius: 20px;
        }
    </style>
</head>
<body>
    <?php
        include("header.php");
    ?>
    <div class="container mb-4">
        <div class="row">
            <?php
                include("db.php");
                $sql = "select * from eviseek_complaint";
                $result = mysqli_query($conn, $sql);
                if(mysqli_num_rows($result) > 0)
                {
                    while($row = mysqli_fetch_assoc($result))
                    {
                        ?>
                        <div class="col-md-6">
                        <div class="card p-4 mt-5">
                    <form action="" method="post" enctype="multipart/form-data">
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="">Name</label>
                                <input type="text" class="form-control" value="Unknown Person" readonly>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="">Department</label>
                                <input type="email" class="form-control" value="<?=$row['eviseek_complaint_department']?>" readonly>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label for="">Message</label>
                                <textarea class="form-control" readonly><?=$row['eviseek_complaint_message']?></textarea>
                            </div>
                        </div>
                        <div class="form-row">
                            <img src="user/uploads/<?=$row["eviseek_complaint_image"]?>" class="form-control" height="150px" alt="">
                        </div>
                    </form>
                </div>
                        </div>
                        <?php
                    }
                }
            ?>
        </div>
    </div>
</body>
</html>